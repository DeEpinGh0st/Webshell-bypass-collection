
## 使用方法

 PHP版 :`xor.php?file=test.php`
 

 
 PY版 : python3 php_venom.py > test.php
 
   即可在同目录生成 test.php
 

